解压后双击 Download-Star-Abyss.cmd。
需要 Windows PowerShell 5.1（Windows 10/11 自带），首次下载需联网。
工具仅下载、验证并解压游戏，不会自动执行游戏，不需要输入令牌。
下载完成后，在桌面的 Star-Abyss-时间 文件夹中运行 Star-Abyss.exe。
每个分块和完整压缩包均验证 SHA-256；现有桌面文件不会被覆盖。
版本为可玩原型 0.1，范围和素材许可包含在游戏包内。
